import tensorflow as tf
from keras.api.models import Model
from keras.api.layers import LSTM, Dense, Input, Lambda, Layer, Dropout, Add, BatchNormalization, Embedding
from keras.api.optimizers import Adam

import numpy as np
import pandas as pd
import logging

from dataset.viewer import select_keys, generate_sequence, apply_ops, concatenate_to_numpy
from predictor.nn.sheduler import OneCycleLR
from predictor.nn.layer import FnLayer, GatedResidualNetwork

from model import _AbstractModel
from predictor import NNPredictor

def split_tensor(input_layer, dimension):
    """
    Splits a tensor along a specified dimension and squeezes the resulting tensors.

    Args:
        input_layer (tf.Tensor): The input tensor to be split.
        dimension (int): The dimension along which to split the tensor.

    Returns:
        List[tf.Tensor]: A list of tensors resulting from the split operation, with the specified dimension squeezed out.
    """
    split_tensors = tf.split(input_layer, input_layer.shape[dimension], axis=dimension)
    split_layers = [Lambda(lambda x: tf.squeeze(x, axis=dimension))(tensor) for tensor in split_tensors]
    return split_layers

def list_to_map(l):
    """
    Converts a list to a dictionary mapping each element to its index.

    Args:
        l (list): The list to be converted.

    Returns:
        dict: A dictionary where the keys are the elements of the list and the values are their corresponding indices.
    """
    return {l[i]: i for i in range(len(l))}

selected_keys = [
    "EBIT",
    "Net Income",
    "Retained Earnings",
    "Cash And Cash Equivalents",
    "Cash Cash Equivalents And Short Term Investments",
    "Total Assets",
    "Long Term Debt And Capital Lease Obligation",
    "Current Debt And Capital Lease Obligation",
    "Total Liabilities Net Minority Interest",
    "Total Equity Gross Minority Interest",
]

preprocess_operators = {
    "EBIT": lambda x: x["EBIT"],
    "Net Income": lambda x: x["Net Income"],
    "Retained Earnings": lambda x: x["Retained Earnings"],
    "Cash": lambda x: x["Cash And Cash Equivalents"],
    "ST Investments": lambda x: x["Cash Cash Equivalents And Short Term Investments"] - x["Cash And Cash Equivalents"],
    "ST Debt": lambda x: x["Current Debt And Capital Lease Obligation"],
    "LT Debt": lambda x: x["Long Term Debt And Capital Lease Obligation"],
    "Total Assets": lambda x: x["Total Assets"],
    "Total Liabilities and Equity": lambda x: x["Total Liabilities Net Minority Interest"] + x["Total Equity Gross Minority Interest"],
    "Check": lambda x: x["Total Assets"] - x["Total Liabilities Net Minority Interest"] - x["Total Equity Gross Minority Interest"],
}

normed_key = "Total Assets"

source_keys = list(preprocess_operators.keys())
target_keys = source_keys

postprocess_operators = {
    "Cash": lambda x: x["Cash"] + x["Total Liabilities and Equity"] - x["Total Assets"],
    "Total Assets": lambda x: x["Total Assets"] + x["Total Liabilities and Equity"] - x["Total Assets"],
    "Check": lambda x: x["Total Assets"] - x["Total Assets"],
}

FEATURE_LIST_STATE = [
    "EBIT",
    "Return from ST Investment",
    "Interest Payments",
    "Net Income",
    "Dividends Payment Next Year",
    "Retained Earnings",
    "Cash",
    "ST Investments",
    "Total Fixed Assets",
    "Total Assets",
    "ST Debt",
    "LT Debt",
    "Equity Investment",
    "Total Liabilities and Equity",
    "Check",
]

FEATURE_LIST_LATENT = [
    "Equity Investment",
    "1 / LT Loan",
    "Minimum Cash Required",
    "Return of ST Investment",
    "Cost of Debt",
    "EBIT",
    "Depreciation",
    "Net Fixed Assets",
    "New Fixed Assets",
]

FEATURE_LIST_TRAINABLE = [
    "EBIT",
    "Net Income",
    "Retained Earnings",
    "Cash",
    "ST Investments",
    "Total Assets",
    "ST Debt",
    "LT Debt",
    "Total Liabilities and Equity",
    "Check",
]

FEATURE_MAP_STATE = list_to_map(FEATURE_LIST_STATE)
FEATURE_MAP_LATENT = list_to_map(FEATURE_LIST_LATENT)
FEATURE_MAP_TRAINABLE = list_to_map(FEATURE_LIST_TRAINABLE)

eps = tf.constant(1e-6)

def extract_state(State, feature_name):
    """
    Extracts the value of a specified feature from the given state.

    Args:
        State (list or array-like): The state from which to extract the feature.
        feature_name (str): The name of the feature to extract.

    Returns:
        The value of the specified feature from the state.

    Raises:
        KeyError: If the feature_name is not found in FEATURE_MAP_TRAINABLE.
    """
    feature_idx = FEATURE_MAP_TRAINABLE[feature_name]
    return State[feature_idx]

def extract_latent(Latent, feature_name):
    """
    Extracts a specific feature from the latent representation.

    Args:
        Latent (list or array-like): The latent representation containing various features.
        feature_name (str): The name of the feature to extract.

    Returns:
        The value of the specified feature from the latent representation.

    Raises:
        KeyError: If the feature_name is not found in FEATURE_MAP_LATENT.
    """
    feature_idx = FEATURE_MAP_LATENT[feature_name]
    return Latent[feature_idx]

def pack_state(state_map):
    """
    Packs the state map into a list based on the order of features in FEATURE_LIST_STATE.

    Args:
        state_map (dict): A dictionary where keys are feature names and values are their corresponding states.

    Returns:
        list: A list of states ordered according to FEATURE_LIST_STATE.

    Raises:
        AssertionError: If the length of state_map does not match the length of FEATURE_LIST_STATE.
    """
    assert len(state_map) == len(FEATURE_LIST_STATE)
    return [state_map[feature_name] for feature_name in FEATURE_LIST_STATE]

def pack_trainable(state_map):
    """
    Packs the trainable features from the state map into a list.

    Args:
        state_map (dict): A dictionary where keys are feature names and values are their corresponding states.

    Returns:
        list: A list of states corresponding to the features in FEATURE_LIST_TRAINABLE.
    """
    return [state_map[feature_name] for feature_name in FEATURE_LIST_TRAINABLE]

def simple_model(CurrState_tf, Latent_tf):
    """
    A simple financial model that processes current state and latent state tensors to compute various financial metrics.
    Args:
        CurrState_tf (tf.Tensor): A tensor representing the current state.
        Latent_tf (tf.Tensor): A tensor representing the latent state.
    Returns:
        NextState_tf (tf.Tensor): A tensor representing the next state.
        Trainable_tf (tf.Tensor): A tensor representing the trainable parameters.
    The function performs the following steps:
    1. Splits the current state tensor and extracts specific financial states.
    2. Splits the latent state tensor and extracts specific latent variables.
    3. Computes various intermediate financial metrics using the extracted states and latent variables.
    4. Maps the computed metrics to a state map.
    5. Packs the state map into tensors for the next state and trainable parameters.
    """
    CurrState = split_tensor(CurrState_tf, -1)

    D26 = extract_state(CurrState, "ST Debt")
    D44 = extract_state(CurrState, "ST Investments")
    D47 = extract_state(CurrState, "Cash")
    D54 = extract_state(CurrState, "ST Debt")
    D62 = extract_state(CurrState, "LT Debt")
    D69 = extract_state(CurrState, "Net Income")
    D71 = extract_state(CurrState, "Retained Earnings")
    D81 = extract_state(CurrState, "ST Debt")

    Latent = split_tensor(Latent_tf, -1)

    E5 = extract_latent(Latent, "Equity Investment")
    E6 = extract_latent(Latent, "1 / LT Loan")
    E9 = extract_latent(Latent, "Minimum Cash Required")
    E10 = extract_latent(Latent, "Return of ST Investment")
    E11 = extract_latent(Latent, "Cost of Debt")
    E12 = extract_latent(Latent, "EBIT")
    E13 = extract_latent(Latent, "Depreciation")
    E15 = extract_latent(Latent, "Net Fixed Assets")
    E16 = extract_latent(Latent, "New Fixed Assets")

    E14 = E12 + E13
    
    E19 = E14
    E22 = -E16
    E23 = E22 + E19

    E58 = D62
    E63 = E11
    E59 = E58 * E63
    E29 = D26
    E55 = E11
    E51 = D54 * E55
    E30 = E51
    E60 = D62 * E6
    E31 = E60
    E32 = E59
    E33 = E29 + E30 + E31 + E32

    E41 = D44
    E42 = E10 * E41
    E43 = E42 + E41

    E26 = E9

    E34 = E26 - E33

    E70 = D69

    E37 = E70

    E36 = E5

    E38 = E36 - E37

    E39 = E38 + E34 + E23

    E44 = D47 + E39 + E43 - E39
    E45 = E43 - E44
    E46 = E45 + E38 + E34 + E23
    E47 = D47 + E46

    E50 = D54
    E51 = D54 * E55
    E52 = D54
    E53 = E51 + E52
    E54 = E50 - E52 + E26
    
    E61 = E59 + E60
    E62 = E58 - E60
    
    

    E66 = E12
    E67 = D44 * E10
    E68 = E59 + E51
    E69 = E66 + E67 - E68
    E70 = D69
    E71 = D71 + D69 - E70

    #E77 = D44
    #E81 = D81

    E76 = E47
    E77 = E44
    E78 = E15
    E79 = E78 + E76 + E77
    E81 = E54
    E82 = E62
    E83 = D81 + E36
    E84 = E69
    E85 = E71
    E86 = E81 + E82 + E83 + E84 + E85
    E87 = E86 - E79

    E77 = E77
    E78 = E78
    E79 = E79
    E81 = E81
    E82 = E82
    E83 = E83
    E86 = E86

    state_map = {
        "EBIT": E66,
        "Return from ST Investment": E67,
        "Interest Payments": E68,
        "Net Income": E69,
        "Dividends Payment Next Year": E70,
        "Retained Earnings": E71,
        "Cash": E76,
        "ST Investments": E77,
        "Total Fixed Assets": E78,
        "Total Assets": E79,
        "ST Debt": E81,
        "LT Debt": E82,
        "Equity Investment": E83,
        "Total Liabilities and Equity": E86,
        "Check": E87,
    }

    packed_state = pack_state(state_map)
    NextState_tf = tf.stack(packed_state, axis=-1)

    packed_trainable = pack_trainable(state_map)
    Trainable_tf = tf.stack(packed_trainable, axis=-1)

    return NextState_tf, Trainable_tf

class StackLayer(Layer):
    """
    A custom Keras layer that stacks the input tensors along a new dimension.

    Methods
    -------
    call(inputs)
        Stacks the input tensors along the last axis.

    Parameters
    ----------
    inputs : tuple
        A tuple containing three elements:
        - inputs: The main input tensor.
        - Trainable: A tensor indicating whether the layer is trainable.
        - feature_emb: A tensor containing feature embeddings.

    Returns
    -------
    tf.Tensor
        A tensor with the input tensors stacked along the last axis.
    """
    def call(self, inputs):
        inputs, Trainable, feature_emb = inputs
        feature_emb =  tf.tile(feature_emb, [tf.shape(inputs)[0], tf.shape(inputs)[1], 1])
        return tf.stack([inputs, Trainable, feature_emb], axis=-1)

class SqueezeLayer(Layer):
    """
    A custom Keras layer that applies the `tf.squeeze` operation to its inputs.

    This layer removes dimensions of size 1 from the shape of a tensor. It is 
    useful when you need to remove single-dimensional entries from the shape 
    of a tensor.

    Methods
    -------
    call(inputs)
        Applies the `tf.squeeze` operation to the inputs tensor.

    Parameters
    ----------
    inputs : tensor
        The input tensor to be squeezed.

    Returns
    -------
    tensor
        The squeezed tensor with dimensions of size 1 removed.
    """
    def call(self, inputs):
        return tf.squeeze(inputs, axis=-1)

def shape_fn(input_shapes):
    """
    Computes the shapes of the next state and trainable tensors based on the input shapes.

    Args:
        input_shapes (list of tuples): A list containing the shapes of the input tensors. 
                                       The first element of the list should be a tuple representing 
                                       the shape of the input tensor, where the first element is 
                                       the batch size, the second element is the sequence length, 
                                       and the third element is the number of features.

    Returns:
        list of tuples: A list containing two tuples:
                        - The shape of the next state tensor, which has the same batch size and 
                          sequence length as the input tensor, but with a number of features 
                          equal to the length of FEATURE_LIST_STATE.
                        - The shape of the trainable tensor, which has the same batch size and 
                          sequence length as the input tensor, but with a number of features 
                          equal to the length of FEATURE_LIST_TRAINABLE.
    """
    batch_size, seq_len, _ = input_shapes[0]
    next_state_shape = (batch_size, seq_len, len(FEATURE_LIST_STATE))
    trainable_shape = (batch_size, seq_len, len(FEATURE_LIST_TRAINABLE))
    return [next_state_shape, trainable_shape]

def create_model(args):
    """
    Creates and compiles a neural network model based on the provided arguments.
    Args:
        args: A namespace or dictionary containing model configuration parameters. 
              Expected keys and structure:
              - args.model.predictor.arch.use_norm: Boolean indicating whether to use batch normalization.
              - args.model.predictor.arch.hidden_dim: Integer, the number of hidden units in the dense and LSTM layers.
              - args.model.predictor.arch.layer_num: Integer, the number of LSTM layers.
              - args.model.predictor.arch.activation: String, the activation function for the alpha layer.
              - args.model.predictor.fit.dropout_rate: Float, the dropout rate for the Dropout layers.
    Returns:
        model: A compiled Keras Model object with the following outputs:
               - 'NextState': The next state of the model.
               - 'Trainable': The trainable output of the model.
               - 'alpha': The alpha value used for combining trainable and single state outputs.
    """
    x = Input(shape=(None, len(source_keys)))
    if args.model.predictor.arch.use_norm:
        x_normed = BatchNormalization(epsilon=1e-6)(x)
        embed = Dense(args.model.predictor.arch.hidden_dim)(x_normed)
    else:
        embed = Dense(args.model.predictor.arch.hidden_dim)(x)
    last_state = embed
    
    for _ in range(args.model.predictor.arch.layer_num):
        cur_state = LSTM(args.model.predictor.arch.hidden_dim, return_sequences=True)(last_state)
        cur_state = Dropout(args.model.predictor.fit.dropout_rate)(cur_state)
        last_state = Add()([last_state, cur_state])
    hidden_x = Dense(len(target_keys))(last_state)
    model_out, model_y = FnLayer(simple_model, shape_fn)([x, hidden_x])

    model = Model(x, {'model_out': model_out, 'model_y': model_y})
    model.compile(optimizer=Adam(), loss={'model_y': 'mse'})
    return model

class LatentPredictor(NNPredictor):
    """
    LatentPredictor is a neural network predictor that initializes a model and 
    provides a method to convert datasets to TensorFlow datasets.

    Args:
        args (dict): A dictionary of arguments required to create the model.

    Methods:
        __init__(self, args):
            Initializes the LatentPredictor with a model created using the provided arguments.
        
        _to_tfdata(self, dataset, batch_size):
            Converts a given dataset to a TensorFlow dataset and batches it.

            Args:
                dataset (dict): A dictionary containing 'source' and 'target' data.
                batch_size (int): The size of the batches in which the dataset will be divided.

            Returns:
                tf.data.Dataset: A TensorFlow dataset object.
    """
    def __init__(self, args):
        model = create_model(args)
        model.summary(print_fn=logging.info)
        super().__init__(model, args)

    def _to_tfdata(self, dataset, batch_size):
        dataset_tf = tf.data.Dataset.from_tensor_slices((dataset["source"], dataset["target"]))
        dataset_tf = dataset_tf.batch(batch_size)
        return dataset_tf
    
def norm_data(data, norm_key=None):
    """
    Normalize the data based on the provided normalization key.

    Parameters:
    data (dict): A dictionary containing the data to be normalized. It should have the keys:
                 - "data": A dictionary where each key maps to a list of numerical values.
                 - "meta_info": A dictionary containing metadata information.
    norm_key (str, optional): The key to use for normalization. If not provided, each key will be normalized by its own first value.

    Returns:
    list: A list containing a single dictionary with the keys:
          - "data": A dictionary with the same keys as the input data, where each value is normalized.
          - "meta_info": The original metadata dictionary with an additional key "normed_base" that contains the base values used for normalization.
    """
    normed = {}
    normed_base = {}
    for key in data["data"].keys():
        normed_base[key] = data["data"][norm_key][0:1] if norm_key else data["data"][key][0:1]
        normed[key] = data["data"][key] / normed_base[key]
    meta_info = data['meta_info']
    meta_info['normed_base'] = normed_base
    return [{"data": normed, "meta_info": meta_info}]

def generate_source_target(data, source_keys, target_keys):
    """
    Generates a list containing a dictionary with source and target data along with meta information.

    Args:
        data (dict): A dictionary containing the data and meta information.
        source_keys (list): A list of keys to extract source data from the 'data' dictionary.
        target_keys (list): A list of keys to extract target data from the 'data' dictionary.

    Returns:
        list: A list containing a single dictionary with 'source', 'target', and 'meta_info' keys.
              'source' and 'target' are dictionaries with the specified keys and their corresponding values.
              'meta_info' is directly taken from the input data.
    """
    source = {key: data["data"][key][:-1] for key in source_keys}
    target = {key: data["data"][key][1:] for key in target_keys}
    return [{"source": source, "target": target, "meta_info": data['meta_info']}]

def reshape_to_model(dataset):
    """
    Reshapes and transposes the 'source' and 'target' arrays in the given dataset.

    Args:
        dataset (dict): A dictionary containing 'source', 'target', and 'meta_info' keys.
            - 'source' (np.ndarray): The source array to be reshaped and transposed.
            - 'target' (np.ndarray): The target array to be reshaped and transposed.
            - 'meta_info' (any): Additional metadata information.

    Returns:
        dict: A dictionary containing the reshaped and transposed 'source' and 'target' arrays,
              along with the original 'meta_info'.
            - 'source' (np.ndarray): The reshaped and transposed source array.
            - 'target' (np.ndarray): The reshaped and transposed target array.
            - 'meta_info' (any): The original metadata information from the input dataset.
    """
    source_array = dataset['source']
    source_array = np.transpose(source_array, (0, 2, 1))
    source_array = source_array.reshape(source_array.shape[0], source_array.shape[1], source_array.shape[2])
    target_array = dataset['target']
    target_array = np.transpose(target_array, (0, 2, 1))
    target_array = target_array.reshape(target_array.shape[0], target_array.shape[1], target_array.shape[2])
    return {"source": source_array, "target": target_array, "meta_info": dataset['meta_info']}
    
class V1Model(_AbstractModel):
    def __init__(self, args):
        super().__init__(args)
        self.predictor = LatentPredictor(args)

    def _to_modeldata(self, dataset):
        selected_data = sum([select_keys(data, selected_keys) for data in dataset], start=[])
        sequences = sum([generate_sequence(data, self.args.data.length) for data in selected_data], start=[])
        preprocessed_data = sum([apply_ops(data, preprocess_operators) for data in sequences], start=[])
        normed_data = sum([norm_data(data, norm_key=normed_key) for data in preprocessed_data], start=[])
        source_target = sum([generate_source_target(data, source_keys, target_keys) for data in normed_data], start=[])
        concatenated = concatenate_to_numpy(source_target)
        model_data = reshape_to_model(concatenated)
        return model_data

    def _recover_predict(self, modeldata, predicted):
        recovered_data = []
        for idx in range(predicted.shape[0]):
            normed_base = modeldata['meta_info'][idx]['normed_base']
            data = {key: predicted[idx, :, i] * normed_base[key] for i, key in enumerate(target_keys)}
            recovered_data.append({"data": data, "meta_info": modeldata['meta_info'][idx]})
        postprocessed_data = sum([apply_ops(data, postprocess_operators, keep_keys=True) for data in recovered_data], start=[])
        raw_financial_data = []
        for idx in range(len(postprocessed_data)):
            normed_base = modeldata['meta_info'][idx]['normed_base']
            raw_financial_data.append({
                'meta_info': {"ticker_name": modeldata['meta_info'][idx]["ticker_name"]},
                'raw_data': {
                    'source': {key: modeldata['source'][idx, :, i] * normed_base[key] for i, key in enumerate(source_keys)},
                    'target': {key: modeldata['target'][idx, :, i] * normed_base[key] for i, key in enumerate(target_keys)},
                },
                'predicted': {
                    'target': postprocessed_data[idx]['data'],
                },
            })
        return raw_financial_data

    def _fit(self, train_modeldata, dev_modeldata):
        callbacks = [OneCycleLR(max_lr=self.args.model.predictor.fit.learning_rate, total_steps=self.args.model.predictor.fit.epoch_num * len(train_modeldata['source']))]
        self.predictor.fit(train_modeldata, dev_modeldata, callbacks=callbacks)
    
    def _predict(self, test_modeldata):
        return self.predictor.predict(test_modeldata)["model_y"]