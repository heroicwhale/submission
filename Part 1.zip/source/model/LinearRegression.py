import numpy as np
import pandas as pd

from dataset.viewer import select_keys, generate_sequence, apply_ops, concatenate_to_numpy

from model import _AbstractModel
from predictor import SKPredictor

from sklearn.linear_model import LinearRegression

selected_keys = [
    "EBIT",
    "Net Income",
    "Retained Earnings",
    "Cash And Cash Equivalents",
    "Cash Cash Equivalents And Short Term Investments",
    "Total Assets",
    "Long Term Debt And Capital Lease Obligation",
    "Current Debt And Capital Lease Obligation",
    "Total Liabilities Net Minority Interest",
    "Total Equity Gross Minority Interest",
]

preprocess_operators = {
    "EBIT": lambda x: x["EBIT"],
    "Net Income": lambda x: x["Net Income"],
    "Retained Earnings": lambda x: x["Retained Earnings"],
    "Cash": lambda x: x["Cash And Cash Equivalents"],
    "ST Investments": lambda x: x["Cash Cash Equivalents And Short Term Investments"] - x["Cash And Cash Equivalents"],
    "ST Debt": lambda x: x["Current Debt And Capital Lease Obligation"],
    "LT Debt": lambda x: x["Long Term Debt And Capital Lease Obligation"],
    "Total Assets": lambda x: x["Total Assets"],
    "Total Liabilities and Equity": lambda x: x["Total Liabilities Net Minority Interest"] + x["Total Equity Gross Minority Interest"],
    "Check": lambda x: x["Total Assets"] - x["Total Liabilities Net Minority Interest"] - x["Total Equity Gross Minority Interest"],
}

source_keys = list(preprocess_operators.keys())
target_keys = source_keys

postprocess_operators = {
    "Cash": lambda x: x["Cash"] + x["Total Liabilities and Equity"] - x["Total Assets"],
    "Total Assets": lambda x: x["Total Assets"] + x["Total Liabilities and Equity"] - x["Total Assets"],
    "Check": lambda x: x["Total Assets"] - x["Total Assets"],
}

def generate_source_target(data, source_keys, target_keys):
    """
    Generates a list containing a dictionary with source and target data extracted from the input data.

    Args:
        data (dict): The input data dictionary containing 'data' and 'meta_info' keys.
        source_keys (list): A list of keys to extract source data from the 'data' dictionary.
        target_keys (list): A list of keys to extract target data from the 'data' dictionary.

    Returns:
        list: A list containing a single dictionary with 'source', 'target', and 'meta_info' keys.
              'source' is a dictionary with keys from source_keys and their corresponding values from the input data (excluding the last element).
              'target' is a dictionary with keys from target_keys and their corresponding values from the input data (only the last element).
              'meta_info' is copied from the input data.
    """
    source = {key: data["data"][key][:-1] for key in source_keys}
    target = {key: data["data"][key][-1:] for key in target_keys}
    return [{"source": source, "target": target, "meta_info": data['meta_info']}]

def reshape_to_model(dataset):
    """
    Reshapes the 'source' and 'target' arrays in the dataset to be suitable for the model.

    The function transposes the 'source' and 'target' arrays from shape (batch_size, height, width)
    to (batch_size, width, height), and then reshapes them to (batch_size, width * height).

    Args:
        dataset (dict): A dictionary containing 'source', 'target', and 'meta_info' keys.
                        'source' and 'target' are expected to be numpy arrays of shape 
                        (batch_size, height, width).

    Returns:
        dict: A dictionary with the reshaped 'source' and 'target' arrays, and the original 'meta_info'.
    """
    source_array = dataset['source']
    source_array = np.transpose(source_array, (0, 2, 1))
    source_array = source_array.reshape(source_array.shape[0], source_array.shape[1] * source_array.shape[2])
    target_array = dataset['target']
    target_array = np.transpose(target_array, (0, 2, 1))
    target_array = target_array.reshape(target_array.shape[0], target_array.shape[1] * target_array.shape[2])
    return {"source": source_array, "target": target_array, "meta_info": dataset['meta_info']}

class LinearRegressionModel(_AbstractModel):
    """
    A linear regression model class that extends the _AbstractModel.
    Attributes:
        predictor (SKPredictor): An instance of SKPredictor initialized with LinearRegression and arguments.
    Methods:
        __init__(args):
            Initializes the LinearRegressionModel with the given arguments.
        _to_modeldata(dataset):
            Converts the input dataset into model data by selecting keys, generating sequences, applying preprocessing operations, 
            generating source and target data, concatenating, and reshaping to model format.
        _recover_predict(modeldata, predicted):
            Recovers the predicted data into a structured format including meta information, raw data, and postprocessed predictions.
        _fit(train_modeldata, dev_modeldata, *args, **kwargs):
            Fits the predictor using the training model data.
        _predict(test_modeldata, *args, **kwargs):
            Predicts the target values using the test model data.
    """
    def __init__(self, args):
        super().__init__(args)
        self.predictor = SKPredictor(LinearRegression(), args.predictor)

    def _to_modeldata(self, dataset):
        selected_data = sum([select_keys(data, selected_keys) for data in dataset], start=[])
        sequences = sum([generate_sequence(data, self.args.data.length) for data in selected_data], start=[])
        preprocessed_data = sum([apply_ops(data, preprocess_operators) for data in sequences], start=[])
        source_target = sum([generate_source_target(data, source_keys, target_keys) for data in preprocessed_data], start=[])
        concatenated = concatenate_to_numpy(source_target)
        model_data = reshape_to_model(concatenated)
        return model_data

    def _recover_predict(self, modeldata, predicted):
        recovered_data = []
        for idx in range(predicted.shape[0]):
            data = {key: predicted[idx, i] for i, key in enumerate(target_keys)}
            recovered_data.append({"data": data, "meta_info": modeldata['meta_info'][idx]})
        postprocessed_data = sum([apply_ops(data, postprocess_operators, keep_keys=True) for data in recovered_data], start=[])
        raw_financial_data = []
        for idx in range(len(postprocessed_data)):
            raw_financial_data.append({
                'meta_info': {"ticker_name": modeldata['meta_info'][idx]["ticker_name"]},
                'raw_data': {
                    'source': {key: modeldata['source'][idx, i * (self.args.data.length-1) : (i+1) * (self.args.data.length-1)] for i, key in enumerate(source_keys)},
                    'target': {key: modeldata['target'][idx, i] for i, key in enumerate(target_keys)},
                },
                'predicted': {
                    'target': postprocessed_data[idx]['data'],
                },
            })
        return raw_financial_data


    def _fit(self, train_modeldata, dev_modeldata, *args, **kwargs):
        self.predictor.fit((train_modeldata['source'], train_modeldata['target']))
    
    def _predict(self, test_modeldata, *args, **kwargs):
        return self.predictor.predict(test_modeldata['source'])