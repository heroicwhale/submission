import logging

class _AbstractModel(object):
    """
    _AbstractModel is an abstract base class for machine learning models. It provides a template for implementing
    custom models by defining the following abstract methods that must be overridden in subclasses:
        - _to_modeldata: Converts raw dataset into model-specific data format.
        - _recover_predict: Recovers the predicted results into a desired format.
        - _fit: Trains the model using the provided training and development data.
        - _predict: Generates predictions using the test data.
    Attributes:
        args: Arguments required for initializing the model.
    Methods:
        fit(train_data, dev_data=None):
            Fits the model using the provided training data and optional development data.
        predict(test_data):
            Generates predictions for the provided test data.
    """
    def __init__(self, args):
        self.args = args

    def _to_modeldata(self, dataset, *args, **kwargs):
        raise NotImplementedError
    
    def _recover_predict(self, modeldata, predicted, *args, **kwargs):
        raise NotImplementedError
    
    def _fit(self, train_modeldata, dev_modeldata, *args, **kwargs):
        raise NotImplementedError
    
    def _predict(self, test_modeldata, *args, **kwargs):
        raise NotImplementedError

    def fit(self, train_data, dev_data=None):
        logging.info("Fitting the model...")
        train_modeldata = self._to_modeldata(train_data)
        if dev_data is not None:
            dev_modeldata = self._to_modeldata(dev_data)
        else:
            dev_modeldata = None
        self._fit(train_modeldata, dev_modeldata)
        logging.info("Model fitted.")

    def predict(self, test_data):
        logging.info("Predicting...")
        test_modeldata = self._to_modeldata(test_data)
        predicted = self._predict(test_modeldata)
        recovered = self._recover_predict(test_modeldata, predicted)
        logging.info("Prediction done.")
        return recovered
