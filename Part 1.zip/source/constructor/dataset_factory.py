from dataset.fetcher import YahooFinanceFetcher
from dataset.loader import SP500Loader
from dataset import Dataset

class DatasetFactory(object):
    @staticmethod
    def from_config(args):
        """
        Creates a dataset from the given configuration arguments.
        Args:
            args: An object containing configuration parameters. Expected attributes:
                - args.data.fetcher.name: The name of the data fetcher (e.g., 'yahoo').
                - args.data.loader.name: The name of the data loader (e.g., 'SP500').
                - args.exp.cache_dir: The directory path for caching data.
        Returns:
            Dataset: An instance of the Dataset class containing the loaded data.
        Raises:
            ValueError: If the specified fetcher or loader name is not found.
        """
        if args.data.fetcher.name == 'yahoo':
            fetch_fn = YahooFinanceFetcher.fetch
        else:
            raise ValueError(f"Fetcher {args.data.fetcher.name} not found")
        
        if args.data.loader.name == 'SP500':
            data = SP500Loader.load_dataset(fetch_fn, args.exp.cache_dir)
            dataset = Dataset(data)
        else:
            raise ValueError(f"Loader {args.data.loader.name} not found")

        return dataset