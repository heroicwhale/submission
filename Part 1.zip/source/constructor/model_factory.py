from enum import Enum
from model.LinearRegression import LinearRegressionModel
from model.V1 import V1Model
from model.V2 import V2Model
from model.V3 import V3Model
from model.V4 import V4Model

class ModelName(Enum):
    LINEAR_REGRESSION = 'LinearRegression'
    V1 = 'V1'
    V2 = 'V2'
    V3 = 'V3'
    V4 = 'V4'

class ModelFactory(object):
    @staticmethod
    def from_config(args):
        """
        Create a model instance from the given configuration.

        Args:
            args: An object containing the model configuration. It must have an attribute `model` with a `name` attribute specifying the model type.

        Returns:
            An instance of the specified model.

        Raises:
            ValueError: If the specified model name is not found.
        """
        model_name = ModelName(args.model.name)
        
        if model_name == ModelName.LINEAR_REGRESSION:
            return LinearRegressionModel(args)
        elif model_name == ModelName.V1:
            return V1Model(args)
        elif model_name == ModelName.V2:
            return V2Model(args)
        elif model_name == ModelName.V3:
            return V3Model(args)
        elif model_name == ModelName.V4:
            return V4Model(args)
        else:
            raise ValueError(f"Model {args.model.name} not found")
