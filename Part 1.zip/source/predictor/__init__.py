import tensorflow as tf
from utils import LossLogger

class _AbstractPredictor(object):
    """
    An abstract base class for predictors.

    Attributes:
        model: The model to be used for prediction.
        args: Additional arguments required for the model.

    Methods:
        fit(*args, **kwargs):
            Abstract method to fit the model. Must be implemented by subclasses.
        predict(*args, **kwargs):
            Abstract method to make predictions using the model. Must be implemented by subclasses.
    """
    def __init__(self, model, args):
        self.model = model
        self.args = args

    def fit(self, *args, **kwargs):
        raise NotImplementedError

    def predict(self, *args, **kwargs):
        raise NotImplementedError

class NNPredictor(_AbstractPredictor):
    """
    NNPredictor is a neural network-based predictor class that extends the _AbstractPredictor class.
    
    Attributes:
        model: The neural network model to be used for prediction.
        args: Arguments containing model configuration parameters.
        log_callback: An instance of LossLogger to log the loss during training and prediction.
    
    Methods:
        __init__(self, model, args):
            Initializes the NNPredictor with the given model and arguments.
        
        _to_tfdata(self, dataset, batch_size):
            Converts a dataset into a TensorFlow dataset and batches it.
        
        fit(self, train_data, dev_data=None, callbacks=None):
            Trains the model using the provided training data and optional validation data.
        
        predict(self, test_data):
            Predicts the output for the given test data.
    """
    def __init__(self, model, args):
        super().__init__(model, args)
        self.log_callback = LossLogger()

    def _to_tfdata(self, dataset, batch_size):
        dataset_tf = tf.data.Dataset.from_tensor_slices(dataset)
        dataset_tf = dataset_tf.batch(batch_size)
        return dataset_tf

    def fit(self, train_data, dev_data=None, callbacks=None):
        train_tfdata = self._to_tfdata(train_data, self.args.model.predictor.fit.batch_num)
        if dev_data is not None:
            dev_tfdata = self._to_tfdata(dev_data, self.args.model.predictor.predict.batch_num)
        else:
            dev_tfdata = None
        if callbacks is None:
            callbacks = []
        self.model.fit(train_tfdata, validation_data=dev_tfdata, epochs=self.args.model.predictor.fit.epoch_num, callbacks=callbacks+[self.log_callback])

    def predict(self, test_data):
        test_tfdata = self._to_tfdata(test_data, self.args.model.predictor.predict.batch_num)
        output = self.model.predict(test_tfdata, callbacks=[self.log_callback])
        return output
    
class SKPredictor(_AbstractPredictor):
    """
    SKPredictor is a class that wraps around a scikit-learn model to provide a consistent interface for fitting and predicting.

    Attributes:
        model: The scikit-learn model to be used for predictions.
        args: Additional arguments for the predictor.

    Methods:
        __init__(model, args):
            Initializes the SKPredictor with a given model and arguments.
        
        fit(train_data):
            Fits the model using the provided training data.
            Args:
                train_data (tuple): A tuple containing the training features and labels.
        
        predict(test_data):
            Predicts the output using the fitted model and provided test data.
            Args:
                test_data (array-like): The data to predict on.
            Returns:
                array-like: The predicted output.
    """
    def __init__(self, model, args):
        super().__init__(model, args)

    def fit(self, train_data):
        self.model.fit(train_data[0], train_data[1])

    def predict(self, test_data):
        output = self.model.predict(test_data)
        return output