import numpy as np
import tensorflow as tf
from keras.api.layers import Dense, LayerNormalization, MultiHeadAttention, Dropout, Layer

class PositionalEncoding(tf.keras.layers.Layer):
    """
    A Keras Layer that adds positional encoding to the input tensor.

    Positional encoding is used to inject some information about the relative or absolute position of the tokens in the sequence. 
    This layer computes the positional encoding and adds it to the input embeddings.

    Attributes:
        pos_encoding (tf.Tensor): The positional encoding tensor.

    Methods:
        __init__(maxlen, embed_dim):
            Initializes the PositionalEncoding layer with the maximum length of the sequence and the embedding dimension.
        
        get_angles(pos, i, embed_dim):
            Computes the angles for the positional encoding.
        
        positional_encoding(maxlen, embed_dim):
            Generates the positional encoding matrix.
        
        call(inputs):
            Adds the positional encoding to the input tensor.
    """
    def __init__(self, maxlen, embed_dim):
        super(PositionalEncoding, self).__init__()
        self.pos_encoding = self.positional_encoding(maxlen, embed_dim)

    def get_angles(self, pos, i, embed_dim):
        angle_rates = 1 / np.power(10000, (2 * (i // 2)) / np.float32(embed_dim))
        return pos * angle_rates

    def positional_encoding(self, maxlen, embed_dim):
        angle_rads = self.get_angles(np.arange(maxlen)[:, np.newaxis],
                                     np.arange(embed_dim)[np.newaxis, :],
                                     embed_dim)
        angle_rads[:, 0::2] = np.sin(angle_rads[:, 0::2])
        angle_rads[:, 1::2] = np.cos(angle_rads[:, 1::2])
        pos_encoding = angle_rads[np.newaxis, ...]
        return tf.cast(pos_encoding, dtype=tf.float32)

    def call(self, inputs):
        return inputs + self.pos_encoding[:, :tf.shape(inputs)[1], :]

class TransformerBlock(tf.keras.layers.Layer):
    """
    TransformerBlock is a custom Keras layer that implements a single block of the Transformer architecture.
    
    Args:
        embed_dim (int): Dimensionality of the embedding space.
        num_heads (int): Number of attention heads.
        ff_dim (int): Dimensionality of the feed-forward network.
        rate (float, optional): Dropout rate. Defaults to 0.1.
    
    Attributes:
        att (tf.keras.layers.MultiHeadAttention): Multi-head attention layer.
        ffn (tf.keras.Sequential): Feed-forward network consisting of two dense layers.
        layernorm1 (tf.keras.layers.LayerNormalization): Layer normalization applied after the attention layer.
        layernorm2 (tf.keras.layers.LayerNormalization): Layer normalization applied after the feed-forward network.
        dropout1 (tf.keras.layers.Dropout): Dropout layer applied after the attention layer.
        dropout2 (tf.keras.layers.Dropout): Dropout layer applied after the feed-forward network.
    
    Methods:
        call(inputs, training):
            Forward pass of the Transformer block.
            
            Args:
                inputs (tf.Tensor): Input tensor.
                training (bool): Boolean indicating whether the layer should behave in training mode or inference mode.
            
            Returns:
                tf.Tensor: Output tensor after applying the Transformer block.
    """
    def __init__(self, embed_dim, num_heads, ff_dim, rate=0.1):
        super(TransformerBlock, self).__init__()
        self.att = MultiHeadAttention(num_heads=num_heads, key_dim=embed_dim)
        self.ffn = tf.keras.Sequential(
            [Dense(ff_dim, activation="relu"), Dense(embed_dim),]
        )
        self.layernorm1 = LayerNormalization(epsilon=1e-6)
        self.layernorm2 = LayerNormalization(epsilon=1e-6)
        self.dropout1 = Dropout(rate)
        self.dropout2 = Dropout(rate)

    def call(self, inputs, training):
        attn_output = self.att(inputs, inputs)
        attn_output = self.dropout1(attn_output, training=training)
        out1 = self.layernorm1(inputs + attn_output)
        ffn_output = self.ffn(out1)
        ffn_output = self.dropout2(ffn_output, training=training)
        return self.layernorm2(out1 + ffn_output)

class AddAndNorm(Layer):
    """
    AddAndNorm Layer

    This layer performs the addition of the input tensor `x` and the output of a sublayer `sublayer_output`, 
    followed by layer normalization.

    Attributes:
        layer_norm (LayerNormalization): An instance of the LayerNormalization class.

    Methods:
        call(x, sublayer_output):
            Adds the input tensor `x` and the sublayer output `sublayer_output`, 
            then applies layer normalization to the result.

    Args:
        **kwargs: Additional keyword arguments for the Layer base class.
    """
    def __init__(self, **kwargs):
        super(AddAndNorm, self).__init__(**kwargs)
        self.layer_norm = LayerNormalization()

    def call(self, x, sublayer_output):
        return self.layer_norm(x + sublayer_output)

class GatedResidualNetwork(Layer):
    """
    Gated Residual Network (GRN) layer.

    This layer implements a gated residual network as described in the paper
    "Temporal Fusion Transformers for Interpretable Multi-horizon Time Series Forecasting".

    Args:
        dim_input (int): The dimension of the input.
        hidden_units (int): The number of hidden units in the dense layer.
        dropout_rate (float, optional): The dropout rate to be applied after the first dense layer. Defaults to 0.1.
        **kwargs: Additional keyword arguments for the Layer base class.

    Attributes:
        hidden_units (int): The number of hidden units in the dense layer.
        dropout_rate (float): The dropout rate to be applied after the first dense layer.
        dense1 (Dense): The first dense layer with ReLU activation.
        dropout1 (Dropout): The dropout layer applied after the first dense layer.
        dense2 (Dense): The second dense layer.
        gate (Dense): The gating layer with sigmoid activation.
        add_and_norm (AddAndNorm): The layer that adds the input and the gated output, followed by normalization.

    Methods:
        call(x):
            Forward pass of the GRN layer.
            
            Args:
                x (Tensor): Input tensor.
            
            Returns:
                Tensor: Output tensor after applying the gated residual network.
    """
    def __init__(self, dim_output, dim_hidden, dropout_rate=0.1, **kwargs):
        super(GatedResidualNetwork, self).__init__(**kwargs)
        self.hidden_units = dim_hidden
        self.dropout_rate = dropout_rate
        self.dense1 = Dense(self.hidden_units, activation='relu')
        self.dropout1 = Dropout(self.dropout_rate)
        self.dense2 = Dense(dim_output)
        self.gate = Dense(dim_output, activation='sigmoid')
        self.add_and_norm = AddAndNorm()

    def call(self, x):
        x1 = self.dense1(x)
        x1 = self.dropout1(x1)
        x1 = self.dense2(x1)
        gate_output = self.gate(x)
        x1 = x1 * gate_output
        return self.add_and_norm(x, x1)

class FnLayer(Layer):
    """
    A custom layer that applies a given function to its inputs.
    Args:
        fn (callable): The function to apply to the inputs.
        output_shape_fn (callable): A function that computes the output shape based on the input shape.
    Methods:
        call(inputs):
            Applies the function `fn` to the inputs.
            Args:
                inputs (tuple): The inputs to the layer.
            Returns:
                The result of applying `fn` to the inputs.
        compute_output_shape(input_shape):
            Computes the output shape of the layer.
            Args:
                input_shape (tuple): The shape of the inputs.
            Returns:
                The shape of the outputs.
    """
    def __init__(self, fn, output_shape_fn):
        super(FnLayer, self).__init__()
        self.fn = fn
        self.output_shape_fn = output_shape_fn

    def call(self, inputs):
        outputs = self.fn(*inputs)
        return outputs
    
    def compute_output_shape(self, input_shape):
        return self.output_shape_fn(input_shape)