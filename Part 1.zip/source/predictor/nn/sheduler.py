import math
import tensorflow as tf

class OneCycleLR(tf.keras.callbacks.Callback):
    """
    A Keras Callback implementing the One Cycle Learning Rate policy.

    The One Cycle Learning Rate policy adjusts the learning rate according to the 
    schedule described in the paper "Super-Convergence: Very Fast Training of Neural Networks 
    Using Large Learning Rates" by Leslie N. Smith.

    Args:
        max_lr (float): The maximum learning rate.
        total_steps (int): The total number of training steps.
        pct_start (float, optional): The percentage of total steps to spend increasing the learning rate. Default is 0.3.
        anneal_strategy (str, optional): The annealing strategy to use ('cos' for cosine annealing, 'linear' for linear annealing). Default is 'cos'.
        div_factor (float, optional): The initial learning rate is max_lr / div_factor. Default is 25.0.
        final_div_factor (float, optional): The minimum learning rate is max_lr / final_div_factor. Default is 1e4.

    Attributes:
        initial_lr (float): The initial learning rate.
        final_lr (float): The final learning rate.
        step (int): The current training step.
        history (dict): A dictionary to store the learning rate history.

    Methods:
        on_train_begin(logs=None): Sets the initial learning rate at the beginning of training.
        on_batch_end(batch, logs=None): Updates the learning rate at the end of each batch and logs it.
        compute_lr(): Computes the current learning rate based on the step and annealing strategy.
    """
    def __init__(self, max_lr, total_steps, pct_start=0.3, anneal_strategy='cos', div_factor=25.0, final_div_factor=1e4):
        super(OneCycleLR, self).__init__()
        self.max_lr = max_lr
        self.total_steps = total_steps
        self.pct_start = pct_start
        self.anneal_strategy = anneal_strategy
        self.div_factor = div_factor
        self.final_div_factor = final_div_factor

        self.initial_lr = max_lr / div_factor
        self.final_lr = max_lr / final_div_factor

        self.step = 0
        self.history = {}

    def on_train_begin(self, logs=None):
        self.model.optimizer.learning_rate = self.initial_lr

    def on_batch_end(self, batch, logs=None):
        self.step += 1
        lr = self.compute_lr()
        self.model.optimizer.learning_rate = lr

        # Log the learning rate to the history
        logs = logs or {}
        logs['lr'] = lr
        self.history.setdefault('lr', []).append(lr)

    def compute_lr(self):
        if self.step < self.total_steps * self.pct_start:
            pct = self.step / (self.total_steps * self.pct_start)
            return self.initial_lr + pct * (self.max_lr - self.initial_lr)
        else:
            pct = (self.step - self.total_steps * self.pct_start) / (self.total_steps * (1 - self.pct_start))
            if self.anneal_strategy == 'cos':
                return self.final_lr + 0.5 * (self.max_lr - self.final_lr) * (1 + math.cos(math.pi * pct))
            else:
                return self.max_lr - pct * (self.max_lr - self.final_lr)