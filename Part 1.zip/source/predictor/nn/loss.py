import numpy as np
import tensorflow as tf

def soft_dtw_loss(y_true, y_pred, gamma=1.0):
    """
    Computes the Soft Dynamic Time Warping (Soft-DTW) loss between the true and predicted sequences.
    Soft-DTW is a differentiable variant of Dynamic Time Warping (DTW) that can be used as a loss function
    for training neural networks. It measures the similarity between two sequences by finding an optimal
    alignment that minimizes the cumulative distance between them.
    Args:
        y_true (tf.Tensor): The ground truth sequences with shape (batch_size, sequence_length, num_features).
        y_pred (tf.Tensor): The predicted sequences with shape (batch_size, sequence_length, num_features).
        gamma (float, optional): The smoothing parameter for Soft-DTW. Default is 1.0.
    Returns:
        tf.Tensor: The mean Soft-DTW loss over the batch.
    """
    def soft_dtw(D, gamma=1.0):
        N, M = D.shape
        R = tf.fill((N + 1, M + 1), tf.constant(np.inf, dtype=tf.float32))
        R = tf.tensor_scatter_nd_update(R, [[0, 0]], [0.0])
    
        for i in range(1, N + 1):
            for j in range(1, M + 1):
                cost = D[i-1, j-1]
                r_val = cost + tf.reduce_min([R[i-1, j], R[i, j-1], R[i-1, j-1]])
                R = tf.tensor_scatter_nd_update(R, [[i, j]], [r_val])
        
        return R[N, M]

    def batch_soft_dtw(args):
        y_true_i, y_pred_i = args
        y_true_i.set_shape(y_pred_i.shape)
        D = tf.norm(tf.expand_dims(y_true_i, 1) - tf.expand_dims(y_pred_i, 0), axis=-1)
        return soft_dtw(D, gamma)
    
    loss = tf.map_fn(batch_soft_dtw, (y_true, y_pred), dtype=tf.float32)
    return tf.reduce_mean(loss)