from dataclasses import dataclass
from typing import List, Any, Iterator


@dataclass
class Dataset(object):
    data: List[Any]

    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, index):
        if isinstance(index, slice):
            return Dataset(self.data[index])
        elif isinstance(index, int):
            return self.data[index]
        else:
            raise TypeError("Invalid argument type.")

    def __iter__(self) -> Iterator[Any]:
        return iter(self.data)

    def apply_index(self, index):
        return Dataset([self.data[i] for i in index])
