import os
import pandas as pd
from tqdm import tqdm

from utils import load_cache, save_cache

class SP500Loader(object):
    """
    A class used to load S&P 500 companies and their financial data.

    Methods
    -------
    _get_sp500_companies():
        Fetches the list of S&P 500 companies from Wikipedia.

    load_dataset(fetch_fn, cache_dir):
        Loads the financial dataset for S&P 500 companies, fetching data if not cached.

    Static Methods
    --------------
    _get_sp500_companies():
        Fetches the list of S&P 500 companies from Wikipedia.

    load_dataset(fetch_fn, cache_dir):
        Loads the financial dataset for S&P 500 companies, fetching data if not cached.

    Parameters
    ----------
    fetch_fn : function
        A function that takes a ticker symbol as input and returns the financial data for that ticker.
    cache_dir : str
        The directory where cached data files are stored.

    Returns
    -------
    list
        A list of dictionaries containing the financial data for S&P 500 companies.
    """
    @staticmethod
    def _get_sp500_companies():
        SP500_COMPANIES_URL = "https://en.wikipedia.org/wiki/List_of_S%26P_500_companies"
        table = pd.read_html(SP500_COMPANIES_URL, header=0)[0]
        return table['Symbol'].tolist()

    @staticmethod
    def load_dataset(fetch_fn, cache_dir):
        SP500LIST_CACHE_FILE = os.path.join(cache_dir, 'sp500list.pkl')
        SP500DATA_CACHE_FILE = os.path.join(cache_dir, 'sp500data.pkl')
        sp500_companies = load_cache(SP500LIST_CACHE_FILE, default=None)
        if sp500_companies is None:
            sp500_companies = SP500Loader._get_sp500_companies()
            save_cache(sp500_companies, SP500LIST_CACHE_FILE)
        financial_data = load_cache(SP500DATA_CACHE_FILE, default=[])
        cached_tickers = [entry['meta_info']['ticker_name'] for entry in financial_data]

        companies_to_fetch = [ticker for ticker in sp500_companies if ticker not in cached_tickers]

        for ticker in tqdm(companies_to_fetch, desc="Fetching financial data"):
            try:
                full_raw_data = fetch_fn(ticker)
                financial_data.append(full_raw_data)
            except Exception as e:
                print(f"Error fetching data for {ticker}: {e}")

        save_cache(financial_data, SP500DATA_CACHE_FILE)

        return financial_data