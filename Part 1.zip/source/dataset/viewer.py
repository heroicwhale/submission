import numpy as np
import pandas as pd

def select_keys(entry, selected_keys):
    """
    Selects specific keys from the 'raw_data' field of an entry and returns the selected data.

    Args:
        entry (dict): A dictionary containing 'raw_data' and 'meta_info'.
            'raw_data' is expected to have 'income' and 'balance' sub-dictionaries.
        selected_keys (list): A list of keys to be selected from the 'raw_data'.

    Returns:
        list: A list containing a single dictionary with 'meta_info' and the selected 'data' if all keys are found.
              Returns an empty list if any key is not found in 'raw_data'.
    """
    raw_data = entry['raw_data']
    selected_data = {"meta_info": entry['meta_info'], "data": {}}
    all_key_flag = True
    for key in selected_keys:
        if key in raw_data.get('income', {}):
            selected_data["data"][key] = raw_data['income'][key]
        elif key in raw_data.get('balance', {}):
            selected_data["data"][key] = raw_data['balance'][key]
        else:
            all_key_flag = False
    return [selected_data] if all_key_flag else []

def generate_sequence(data, length):
    """
    Generates a sequence of data slices from the input data.

    Args:
        data (dict): A dictionary containing the data and meta information. 
                     The dictionary should have the following structure:
                     {
                         "meta_info": <meta information>,
                         "data": {
                             <key1>: <list of values>,
                             <key2>: <list of values>,
                             ...
                         }
                     }
        length (int): The length of each data slice to generate.

    Returns:
        list: A list of dictionaries, each containing a slice of the data and the meta information.
              Each dictionary has the following structure:
              {
                  "meta_info": <meta information>,
                  "data": {
                      <key1>: <list of values>,
                      <key2>: <list of values>,
                      ...
                  }
              }
              The data slices will only be included if they do not contain any NaN values.
    """
    sequence = []
    keys = list(data["data"].keys())
    max_len = len(data["data"][keys[0]])
    for start in range(max_len - length + 1):
        data_slice = {key: data["data"][key][start:start + length] for key in keys}
        if pd.isnull(pd.DataFrame(data_slice)).any().any():
            continue
        sequence.append({"meta_info": data["meta_info"], "data": data_slice})
    return sequence

def apply_ops(data, ops, keep_keys=False):
    """
    Apply a series of operations to the data and return the processed result.

    Args:
        data (dict): A dictionary containing the data to be processed. 
                     It should have at least two keys: 'data' and 'meta_info'.
        ops (dict): A dictionary where keys are new keys for the processed data 
                    and values are functions to be applied to the data.
        keep_keys (bool, optional): If True, keep the original keys in the data. 
                                    Defaults to False.

    Returns:
        list: A list containing a single dictionary with 'meta_info' and the 
              processed 'data'.
    """
    if keep_keys:
        base = data["data"].copy()
    else:
        base = {}
    processed_data = {new_key: func(data["data"]) for new_key, func in ops.items()}
    base.update(processed_data)
    return [{"meta_info": data['meta_info'], "data": base}]

def concatenate_to_numpy(data):
    """
    Converts a list of dictionaries containing 'source', 'target', and 'meta_info' keys into a dictionary of NumPy arrays.

    Args:
        data (list): A list of dictionaries, where each dictionary contains 'source', 'target', and 'meta_info' keys.

    Returns:
        dict: A dictionary with three keys:
            - 'source': A NumPy array containing the values from the 'source' key of each dictionary in the input list.
            - 'target': A NumPy array containing the values from the 'target' key of each dictionary in the input list.
            - 'meta_info': A list containing the 'meta_info' values from each dictionary in the input list.
    """
    source_array = np.array([list(entry['source'].values()) for entry in data])
    target_array = np.array([list(entry['target'].values()) for entry in data])
    return {"source": source_array, "target": target_array, "meta_info": [entry['meta_info'] for entry in data]}