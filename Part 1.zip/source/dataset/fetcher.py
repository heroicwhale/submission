import yfinance as yf
import numpy as np
import pandas as pd

class YahooFinanceFetcher(object):
    """
    A class used to fetch financial data from Yahoo Finance.

    Methods
    -------
    fetch(ticker: str) -> dict
        Fetches the financial data for the given ticker symbol from Yahoo Finance.

    Parameters
    ----------
    ticker : str
        The ticker symbol of the stock to fetch data for.

    Returns
    -------
    dict
        A dictionary containing the financial data, including income statements and balance sheets,
        aligned by time and converted to numpy float64 arrays. The dictionary has the following structure:
        {
                "ticker_name": str
                "time_list": np.ndarray,
                "income": dict,
                "balance": dict
    """
    @staticmethod
    def fetch(ticker):
        stock = yf.Ticker(ticker)
        income_statement = stock.financials
        balance_sheet = stock.balance_sheet

        income_statement = income_statement.T
        balance_sheet = balance_sheet.T

        # Extract time lists for income statement and balance sheet
        income_time_list = income_statement.index.tolist()
        balance_time_list = balance_sheet.index.tolist()

        # Create a union of both time lists to align them
        full_time_list = sorted(set(income_time_list) | set(balance_time_list))

        # Create dictionaries of financial data with float64 values
        income_dict = {col: income_statement[col].reindex(full_time_list).astype(np.float64).values for col in income_statement.columns}
        balance_dict = {col: balance_sheet[col].reindex(full_time_list).astype(np.float64).values for col in balance_sheet.columns}

        # Add time array to the dictionary
        full_time_array = np.array([pd.Timestamp(ts).to_pydatetime() for ts in full_time_list])

        # Combine income_dict and balance_dict into full_raw_data
        full_raw_data = {
            "meta_info": {
                "ticker_name": ticker
            },
            "time_list": full_time_array,
            "raw_data": {
                "income": income_dict,
                "balance": balance_dict
            }
        }

        return full_raw_data