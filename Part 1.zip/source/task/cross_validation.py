import os
import json
import numpy as np
import logging
import csv

from constructor import ModelFactory, DatasetFactory

from utils import split_index, stringify, convert_to_dataframe, stat_frames

def analyze(results, result_dir, analyzed_keys):
    """
    Analyzes the given results and saves the analysis to the specified directory.

    Parameters:
    results (list): A list of dictionaries containing the results to be analyzed.
    result_dir (str): The directory where the analysis results will be saved.
    analyzed_keys (list): A list of keys to be analyzed from the results.

    Returns:
    dict: A dictionary containing the statistical analysis of the results.

    The function performs the following steps:
    1. Creates the result and prediction directories if they do not exist.
    2. Saves all results to a JSON file.
    3. Converts each result to a DataFrame and saves it as a CSV file in the prediction directory.
    4. Computes statistical analysis for the specified keys and saves it to a CSV file.
    """
    pred_dir = os.path.join(result_dir, 'pred')
    allpred_file = os.path.join(result_dir, 'all.json')
    stat_file = os.path.join(result_dir, 'stat.csv')

    os.makedirs(result_dir, exist_ok=True)
    os.makedirs(pred_dir, exist_ok=True)
    with open(allpred_file, 'w') as f:
        json.dump(stringify(results), f, indent=4)

    frames = {x["meta_info"]["ticker_name"]: convert_to_dataframe(x) for x in results}
    for name in frames:
        frames[name].to_csv(os.path.join(pred_dir, f"{name}.csv"))

    with open(stat_file, 'w') as f:
        cur_stats = stat_frames(frames, analyzed_keys)
        writer = csv.DictWriter(f, fieldnames=["","mean","std","max","min","50th","70th","80th","90th","95th"])
        writer.writeheader()
        for key in analyzed_keys:
            writer.writerow({"": key} | cur_stats[key])

    return cur_stats

def analyze_all(all_stats, result_dir, analyzed_keys):
    """
    Analyzes statistical data from multiple sources and writes the results to a CSV file.

    Parameters:
    all_stats (list of dict): A list of dictionaries containing statistical data.
    result_dir (str): The directory where the CSV file will be saved.
    analyzed_keys (list of str): A list of keys to be analyzed from the statistical data.

    Returns:
    dict: A dictionary containing the aggregated statistical data for each key.
    """
    stats = {}
    with open(os.path.join(result_dir, 'all_stats.csv'), 'w') as f:
        for key in analyzed_keys:
            mean_val = np.array([x[key]["mean"] for x in all_stats]).mean()
            std_val = np.array([x[key]["std"] for x in all_stats]).mean()
            max_val = np.array([x[key]["max"] for x in all_stats]).mean()
            min_val = np.array([x[key]["min"] for x in all_stats]).mean()
            p50 = np.percentile([x[key]["50th"] for x in all_stats], 50)
            p70 = np.percentile([x[key]["70th"] for x in all_stats], 50)
            p80 = np.percentile([x[key]["80th"] for x in all_stats], 50)
            p90 = np.percentile([x[key]["90th"] for x in all_stats], 50)
            p95 = np.percentile([x[key]["95th"] for x in all_stats], 50)
            stats[key] = {"mean": mean_val, "std": std_val, "max": max_val, "min": min_val, "50th": p50, "70th": p70, "80th": p80, "90th": p90, "95th": p95}
        writer = csv.DictWriter(f, fieldnames=["","mean","std","max","min","50th","70th","80th","90th","95th"])
        writer.writeheader()
        for key in analyzed_keys:
            writer.writerow({"": key} | stats[key])
    return stats

def run(args):
    """
    Executes the cross-validation process for a given dataset and model configuration.

    Args:
        args (Namespace): A namespace object containing the experiment configuration. 
                          Expected attributes include:
                          - exp.num_fold (int): Number of folds for cross-validation.
                          - exp.shuffle (bool): Whether to shuffle the dataset before splitting.
                          - exp.experiment_dir (str): Directory for saving experiment results.
                          - exp.working_folder (str): Subdirectory for saving fold-specific results.
                          - exp.analyzed_key (list): List of keys to analyze in the results.

    The function performs the following steps:
    1. Creates a dataset using the provided configuration.
    2. Splits the dataset into training and testing indices for each fold.
    3. For each fold:
       a. Logs the start of the fold.
       b. Creates training and testing datasets based on the indices.
       c. Initializes and trains the model using the training dataset.
       d. Predicts results using the testing dataset.
       e. Analyzes the results and logs the statistics.
       f. Saves the fold-specific results.
       g. Logs the end of the fold.
    4. Analyzes and logs the overall statistics across all folds.
    5. Logs the completion of the experiment.
    """
    dataset = DatasetFactory.from_config(args)

    indexes = split_index(len(dataset), [1/args.exp.num_fold] * args.exp.num_fold, shuffle=args.exp.shuffle)

    all_stats = []
    for i in range(args.exp.num_fold):
        logging.info(f"Fold {i} started.")

        train_index = []
        test_index = indexes[i]
        for j in range(args.exp.num_fold):
            if j != i:
                train_index += indexes[j].tolist()
        train_index = np.array(train_index)

        train_dataset = dataset.apply_index(train_index)
        test_dataset = dataset.apply_index(test_index)

        model = ModelFactory.from_config(args)

        model.fit(train_dataset)
        results = model.predict(test_dataset)

        result_dir = os.path.join(args.exp.experiment_dir, args.exp.working_folder, f"fold_{i}")
        cur_stats = analyze(results, result_dir, args.exp.analyzed_key)

        formated_stats = "\n".join([f"{key}: " + ' - '.join(['{}: {:.4f}'.format(k, v) for k, v in cur_stats[key].items()]) for key in args.exp.analyzed_key])
        logging.info("=========BEGIN OF FOLD STATS=========")
        logging.info(formated_stats)
        logging.info("==========END OF FOLD STATS==========")
        logging.info(f"Fold {i} finished.")

        all_stats.append(cur_stats)

    result_dir = os.path.join(args.exp.experiment_dir, args.exp.working_folder)
    stats = analyze_all(all_stats, result_dir, args.exp.analyzed_key)

    formated_stats = "\n".join([f"{key}: " + ' - '.join(['{}: {:.4f}'.format(k, v) for k, v in stats[key].items()]) for key in args.exp.analyzed_key])
    logging.info("=========BEGIN OF FINAL STATS=========")
    logging.info(formated_stats)
    logging.info("==========END OF FINAL STATS==========")

    logging.info("Experiment finished.")