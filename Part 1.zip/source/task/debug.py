import os
import json
import numpy as np
import logging
import csv

from constructor import ModelFactory, DatasetFactory

from utils import split_index, stringify, convert_to_dataframe, stat_frames

def analyze(results, result_dir, analyzed_keys):
    """
    Analyzes the given results and saves the analysis to the specified directory.

    Parameters:
    results (list): A list of dictionaries containing the results to be analyzed.
    result_dir (str): The directory where the analysis results will be saved.
    analyzed_keys (list): A list of keys to be analyzed in the results.

    Returns:
    dict: A dictionary containing the statistical analysis of the frames.

    The function performs the following steps:
    1. Creates the result directory and a subdirectory for predictions if they do not exist.
    2. Saves all results to a JSON file.
    3. Converts each result to a DataFrame and saves each DataFrame as a CSV file in the prediction directory.
    4. Computes statistics for the specified keys and saves them to a CSV file.
    """
    pred_dir = os.path.join(result_dir, 'pred')
    allpred_file = os.path.join(result_dir, 'all.json')
    stat_file = os.path.join(result_dir, 'stat.csv')

    os.makedirs(result_dir, exist_ok=True)
    os.makedirs(pred_dir, exist_ok=True)
    with open(allpred_file, 'w') as f:
        json.dump(stringify(results), f, indent=4)

    frames = {x["meta_info"]["ticker_name"]: convert_to_dataframe(x) for x in results}
    for name in frames:
        frames[name].to_csv(os.path.join(pred_dir, f"{name}.csv"))

    with open(stat_file, 'w') as f:
        cur_stats = stat_frames(frames, analyzed_keys)
        writer = csv.DictWriter(f, fieldnames=["","mean","std","max","min","50th","70th","80th","90th","95th"])
        writer.writeheader()
        for key in analyzed_keys:
            writer.writerow({"": key} | cur_stats[key])

    return cur_stats

def run(args):
    """
    Executes the training, validation, and testing of a machine learning model based on the provided configuration.

    Args:
        args (Namespace): A namespace object containing the experiment configuration parameters.

    The function performs the following steps:
    1. Loads the dataset using the configuration provided in `args`.
    2. Splits the dataset into training, development, and test sets based on the specified ratios.
    3. Initializes the model using the configuration provided in `args`.
    4. Trains the model using the training and development datasets.
    5. Evaluates the model on the test dataset and generates predictions.
    6. Analyzes the results and logs the statistics.
    7. Logs the completion of the experiment.
    """
    dataset = DatasetFactory.from_config(args)

    train_index, dev_index, test_index = split_index(len(dataset), [args.exp.train_ratio, args.exp.dev_ratio, args.exp.test_ratio], shuffle=args.exp.shuffle)

    train_dataset = dataset.apply_index(train_index)
    dev_dataset = dataset.apply_index(dev_index)
    test_dataset = dataset.apply_index(test_index)

    model = ModelFactory.from_config(args)

    model.fit(train_dataset, dev_dataset)
    results = model.predict(test_dataset)

    result_dir = os.path.join(args.exp.experiment_dir, args.exp.working_folder)
    cur_stats = analyze(results, result_dir, args.exp.analyzed_key)

    formated_stats = "\n".join([f"{key}: " + ' - '.join(['{}: {:.4f}'.format(k, v) for k, v in cur_stats[key].items()]) for key in args.exp.analyzed_key])
    logging.info("=========BEGIN OF THE STATS=========")
    logging.info(formated_stats)
    logging.info("==========END OF THE STATS==========")

    logging.info("Experiment finished.")