import argparse
import os
import logging
from utils import Config, fix_seed, get_time_suffix, get_random_suffix, setup_logger
from task import debug_run, cross_validation_run

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--task', choices=['debug', 'cross_validation'], type=str, default='cross_validation')
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--suffix_length', type=int, default=5)
    parser.add_argument('--config_file', type=str, default='config/V4_cross.yaml')
    config = parser.parse_args()

    args = Config.from_yaml(config.config_file)
    args.exp.working_folder = f"{args.exp.name}-{get_time_suffix()}-{get_random_suffix(config.suffix_length)}"

    os.makedirs(os.path.join(args.exp.experiment_dir, args.exp.working_folder), exist_ok=True)

    setup_logger(os.path.join(args.exp.experiment_dir, args.exp.working_folder, 'log.txt'))

    logging.info(f"Task: {config.task}")
    logging.info(f"Seed: {config.seed}")
    logging.info(f"Working folder: {args.exp.working_folder}")
    logging.info(f"=========BEGIN OF THE ARGS=========")
    logging.info(f"{args}")
    logging.info(f"==========END OF THE ARGS==========")

    fix_seed(config.seed)

    if config.task == 'debug':
        debug_run(args)
    elif config.task == 'cross_validation':
        cross_validation_run(args)
    else:
        raise ValueError(f"Unknown task: {config.task}")

if __name__ == "__main__":
    main()