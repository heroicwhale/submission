import unittest
from utils.args import Config
import yaml
import os

class TestConfig(unittest.TestCase):

    def test_init(self):
        config_dict = {'key1': 'value1', 'key2': {'subkey1': 'subvalue1'}}
        config = Config(config_dict)
        self.assertEqual(config.key1, 'value1')
        self.assertIsInstance(config.key2, Config)
        self.assertEqual(config.key2.subkey1, 'subvalue1')

    def test_getattr(self):
        config_dict = {'key1': 'value1'}
        config = Config(config_dict)
        self.assertEqual(config.key1, 'value1')
        self.assertIsNone(config.non_existent_key)

    def test_setattr(self):
        config = Config({})
        config.key1 = 'value1'
        self.assertEqual(config.key1, 'value1')

    def test_delattr(self):
        config_dict = {'key1': 'value1'}
        config = Config(config_dict)
        del config.key1
        self.assertIsNone(config.__dict__.get('key1'))
        with self.assertRaises(AttributeError):
            del config.non_existent_key

    def test_repr(self):
        config_dict = {'key1': 'value1', 'key2': {'subkey1': 'subvalue1'}}
        config = Config(config_dict)
        yaml_repr = yaml.dump(config_dict, default_flow_style=False)
        self.assertEqual(repr(config), yaml_repr)

    def test_from_yaml(self):
        yaml_content = """
        key1: value1
        key2:
          subkey1: subvalue1
        """
        file_path = 'test_config.yaml'
        with open(file_path, 'w') as file:
            file.write(yaml_content)
        
        config = Config.from_yaml(file_path)
        self.assertEqual(config.key1, 'value1')
        self.assertIsInstance(config.key2, Config)
        self.assertEqual(config.key2.subkey1, 'subvalue1')

        os.remove(file_path)

if __name__ == '__main__':
    unittest.main()