import unittest
import numpy as np
import pandas as pd
from utils.converter import stringify, convert_to_dataframe

class TestConverter(unittest.TestCase):

    def test_stringify(self):
        # Test with a dictionary
        data = {'a': 1, 'b': [2, 3], 'c': {'d': 4}}
        expected = {'a': '1', 'b': ['2', '3'], 'c': {'d': '4'}}
        self.assertEqual(stringify(data), expected)

        # Test with a list
        data = [1, 2, [3, 4], {'a': 5}]
        expected = ['1', '2', ['3', '4'], {'a': '5'}]
        self.assertEqual(stringify(data), expected)

        # Test with a tuple
        data = (1, 2, (3, 4), {'a': 5})
        expected = ('1', '2', ('3', '4'), {'a': '5'})
        self.assertEqual(stringify(data), expected)

        # Test with a numpy array
        data = np.array([1, 2, 3])
        expected = ['1', '2', '3']
        self.assertEqual(stringify(data), expected)

    def test_convert_to_dataframe(self):
        data = {
            'raw_data': {
                'source': {
                    'feature1': [1, 2, 3],
                    'feature2': [4, 5, 6]
                },
                'target': {
                    'target1': [7, 8, 9]
                }
            },
            'predicted': {
                'target': {
                    'target1': [10]
                }
            }
        }
        df = convert_to_dataframe(data)
        
        expected_data = {
            'feature1': {0: 1.0, 1: 2.0},
            'feature2': {0: 4.0, 1: 5.0},
            'target1': {2: 9.0, 'pred': 10.0, 'diff': 1.0, 'ratio': 1/9}
        }
        expected_df = pd.DataFrame(expected_data).transpose()
        
        pd.testing.assert_frame_equal(df, expected_df)

if __name__ == '__main__':
    unittest.main()