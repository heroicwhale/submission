import unittest
import random
import os
import logging
import numpy as np
import tensorflow as tf
from utils.init import fix_seed, get_random_suffix, get_time_suffix, LossLogger, setup_logger

class TestUtils(unittest.TestCase):

    def test_get_random_suffix(self):
        length = 10
        suffix = get_random_suffix(length)
        self.assertEqual(len(suffix), length)
        self.assertTrue(all(c.islower() and c.isalpha() for c in suffix))

    def test_get_time_suffix(self):
        time_suffix = get_time_suffix()
        self.assertEqual(len(time_suffix), 14)
        self.assertTrue(time_suffix.isdigit())

    def test_loss_logger(self):
        class MockLogger:
            def __init__(self):
                self.logs = []

            def info(self, message):
                self.logs.append(message)

        mock_logger = MockLogger()
        logging.getLogger('file_only_logger').info = mock_logger.info

        loss_logger = LossLogger()
        loss_logger.on_epoch_end(1, {'loss': 0.1234, 'accuracy': 0.5678})

        self.assertEqual(len(mock_logger.logs), 1)
        self.assertIn('Epoch 1: loss: 0.1234 - accuracy: 0.5678', mock_logger.logs[0])

if __name__ == '__main__':
    unittest.main()