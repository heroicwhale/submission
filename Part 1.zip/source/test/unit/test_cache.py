import os
import pickle
import unittest
from utils.cache import load_cache, save_cache

class TestCacheFunctions(unittest.TestCase):

    def setUp(self):
        self.cache_file = 'test_cache.pkl'
        self.data = {'key': 'value'}

    def tearDown(self):
        if os.path.exists(self.cache_file):
            os.remove(self.cache_file)

    def test_save_cache(self):
        save_cache(self.data, self.cache_file)
        self.assertTrue(os.path.exists(self.cache_file))

    def test_load_cache_existing_file(self):
        with open(self.cache_file, 'wb') as f:
            pickle.dump(self.data, f)
        loaded_data = load_cache(self.cache_file)
        self.assertEqual(loaded_data, self.data)

    def test_load_cache_non_existing_file(self):
        loaded_data = load_cache('non_existing_file.pkl', default=self.data)
        self.assertEqual(loaded_data, self.data)
