import unittest
import numpy as np
from utils.dataset import split_index, stat_frames

class TestDatasetUtils(unittest.TestCase):

    def test_split_index(self):
        length = 10
        ratio_list = [0.5, 0.3, 0.2]
        result = split_index(length, ratio_list, shuffle=False)
        self.assertEqual(len(result), 3)
        self.assertEqual(len(result[0]), 5)
        self.assertEqual(len(result[1]), 3)
        self.assertEqual(len(result[2]), 2)
        self.assertTrue(np.array_equal(result[0], np.array([0, 1, 2, 3, 4])))
        self.assertTrue(np.array_equal(result[1], np.array([5, 6, 7])))
        self.assertTrue(np.array_equal(result[2], np.array([8, 9])))

    def test_split_index_shuffle(self):
        length = 10
        ratio_list = [0.5, 0.3, 0.2]
        result = split_index(length, ratio_list, shuffle=True)
        self.assertEqual(len(result), 3)
        self.assertEqual(len(result[0]), 5)
        self.assertEqual(len(result[1]), 3)
        self.assertEqual(len(result[2]), 2)
        self.assertEqual(sum([len(r) for r in result]), length)

    def test_stat_frames(self):
        frames = {
            "frame1": {"ratio": {"key1": 1.0, "key2": 2.0}},
            "frame2": {"ratio": {"key1": 2.0, "key2": 3.0}},
            "frame3": {"ratio": {"key1": 3.0, "key2": 4.0}},
        }
        target_keys = ["key1", "key2"]
        result = stat_frames(frames, target_keys)
        self.assertEqual(result["key1"]["mean"], 2.0)
        self.assertEqual(result["key1"]["std"], 0.816496580927726)
        self.assertEqual(result["key1"]["max"], 3.0)
        self.assertEqual(result["key1"]["min"], 1.0)
        self.assertEqual(result["key1"]["50th"], 2.0)
        self.assertEqual(result["key1"]["70th"], 2.4)
        self.assertEqual(result["key1"]["80th"], 2.6)
        self.assertEqual(result["key1"]["90th"], 2.8)
        self.assertEqual(result["key1"]["95th"], 2.9)

        self.assertEqual(result["key2"]["mean"], 3.0)
        self.assertEqual(result["key2"]["std"], 0.816496580927726)
        self.assertEqual(result["key2"]["max"], 4.0)
        self.assertEqual(result["key2"]["min"], 2.0)
        self.assertEqual(result["key2"]["50th"], 3.0)
        self.assertEqual(result["key2"]["70th"], 3.4)
        self.assertEqual(result["key2"]["80th"], 3.6)
        self.assertEqual(result["key2"]["90th"], 3.8)
        self.assertEqual(result["key2"]["95th"], 3.9)

if __name__ == '__main__':
    unittest.main()