import unittest
import numpy as np
import pandas as pd
from dataset.viewer import select_keys, generate_sequence, apply_ops, concatenate_to_numpy

class TestViewerFunctions(unittest.TestCase):

    def test_select_keys(self):
        entry = {
            'raw_data': {
                'income': {'salary': 5000, 'bonus': 1000},
                'balance': {'savings': 2000, 'debt': 500}
            },
            'meta_info': 'test_meta'
        }
        selected_keys = ['salary', 'savings']
        expected_output = [{'meta_info': 'test_meta', 'data': {'salary': 5000, 'savings': 2000}}]
        self.assertEqual(select_keys(entry, selected_keys), expected_output)

        selected_keys = ['salary', 'investment']
        self.assertEqual(select_keys(entry, selected_keys), [])

    def test_generate_sequence(self):
        data = {
            'meta_info': 'test_meta',
            'data': {
                'key1': [1, 2, 3, 4, 5],
                'key2': [6, 7, 8, 9, 10]
            }
        }
        length = 3
        expected_output = [
            {'meta_info': 'test_meta', 'data': {'key1': [1, 2, 3], 'key2': [6, 7, 8]}},
            {'meta_info': 'test_meta', 'data': {'key1': [2, 3, 4], 'key2': [7, 8, 9]}},
            {'meta_info': 'test_meta', 'data': {'key1': [3, 4, 5], 'key2': [8, 9, 10]}}
        ]
        self.assertEqual(generate_sequence(data, length), expected_output)

    def test_apply_ops(self):
        data = {
            'meta_info': 'test_meta',
            'data': {
                'key1': [1, 2, 3],
                'key2': [4, 5, 6]
            }
        }
        ops = {
            'sum': lambda x: sum(x['key1']),
            'mean': lambda x: np.mean(x['key2'])
        }
        expected_output = [{'meta_info': 'test_meta', 'data': {'sum': 6, 'mean': 5.0}}]
        self.assertEqual(apply_ops(data, ops), expected_output)

        expected_output_keep_keys = [{'meta_info': 'test_meta', 'data': {'key1': [1, 2, 3], 'key2': [4, 5, 6], 'sum': 6, 'mean': 5.0}}]
        self.assertEqual(apply_ops(data, ops, keep_keys=True), expected_output_keep_keys)

    def test_concatenate_to_numpy(self):
        data = [
            {'source': {'a': 1, 'b': 2}, 'target': {'c': 3, 'd': 4}, 'meta_info': 'meta1'},
            {'source': {'a': 5, 'b': 6}, 'target': {'c': 7, 'd': 8}, 'meta_info': 'meta2'}
        ]
        expected_output = {
            'source': np.array([[1, 2], [5, 6]]),
            'target': np.array([[3, 4], [7, 8]]),
            'meta_info': ['meta1', 'meta2']
        }
        result = concatenate_to_numpy(data)
        np.testing.assert_array_equal(result['source'], expected_output['source'])
        np.testing.assert_array_equal(result['target'], expected_output['target'])
        self.assertEqual(result['meta_info'], expected_output['meta_info'])

if __name__ == '__main__':
    unittest.main()