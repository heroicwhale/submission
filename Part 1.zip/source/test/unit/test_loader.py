import unittest
from unittest.mock import patch, MagicMock
import os
import pandas as pd
from dataset.loader import SP500Loader

class TestSP500Loader(unittest.TestCase):

    @patch('dataset.loader.pd.read_html')
    def test_get_sp500_companies(self, mock_read_html):
        mock_table = pd.DataFrame({'Symbol': ['AAPL', 'MSFT', 'GOOGL']})
        mock_read_html.return_value = [mock_table]

        companies = SP500Loader._get_sp500_companies()
        self.assertEqual(companies, ['AAPL', 'MSFT', 'GOOGL'])
        mock_read_html.assert_called_once_with("https://en.wikipedia.org/wiki/List_of_S%26P_500_companies", header=0)

if __name__ == '__main__':
    unittest.main()