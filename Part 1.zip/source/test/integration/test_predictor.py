import unittest
from unittest.mock import MagicMock
import tensorflow as tf
from sklearn.linear_model import LinearRegression
from predictor import NNPredictor, SKPredictor

class TestIntegration(unittest.TestCase):
    def setUp(self):
        self.nn_model = MagicMock()
        self.sk_model = LinearRegression()
        self.args = MagicMock()
        self.args.model.predictor.fit.batch_num = 32
        self.args.model.predictor.fit.epoch_num = 10
        self.args.model.predictor.predict.batch_num = 32
    def test_sk_predictor_integration(self):
        sk_predictor = SKPredictor(self.sk_model, self.args)
        train_data = (tf.random.uniform((100, 10)).numpy(), tf.random.uniform((100, 1)).numpy())
        sk_predictor.fit(train_data)
        test_data = tf.random.uniform((20, 10)).numpy()
        predictions = sk_predictor.predict(test_data)
        self.assertTrue(hasattr(self.sk_model, 'coef_'))
        self.assertEqual(predictions.shape[0], 20)

if __name__ == '__main__':
    unittest.main()
