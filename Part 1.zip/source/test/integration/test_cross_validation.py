import unittest
import os
import json
import numpy as np
import shutil
from unittest.mock import patch, MagicMock
from task.cross_validation import analyze, analyze_all, run

class TestCrossValidation(unittest.TestCase):

    def setUp(self):
        self.result_dir = 'test_results'
        self.analyzed_keys = ['accuracy', 'precision', 'recall']
        self.results = [
            {
                "meta_info": {"ticker_name": "AAPL"},
                "accuracy": 0.9,
                "precision": 0.8,
                "recall": 0.7
            },
            {
                "meta_info": {"ticker_name": "GOOGL"},
                "accuracy": 0.85,
                "precision": 0.75,
                "recall": 0.65
            }
        ]
        self.all_stats = [
            {
                "accuracy": {"mean": 0.9, "std": 0.05, "max": 0.95, "min": 0.85, "50th": 0.9, "70th": 0.92, "80th": 0.93, "90th": 0.94, "95th": 0.95},
                "precision": {"mean": 0.8, "std": 0.04, "max": 0.84, "min": 0.76, "50th": 0.8, "70th": 0.82, "80th": 0.83, "90th": 0.84, "95th": 0.84},
                "recall": {"mean": 0.7, "std": 0.03, "max": 0.73, "min": 0.67, "50th": 0.7, "70th": 0.71, "80th": 0.72, "90th": 0.73, "95th": 0.73}
            }
        ]

    def tearDown(self):
        if os.path.exists(self.result_dir):
            shutil.rmtree(self.result_dir)

    @patch('task.cross_validation.convert_to_dataframe')
    @patch('task.cross_validation.stat_frames')
    @patch('task.cross_validation.stringify')
    def test_analyze(self, mock_stringify, mock_stat_frames, mock_convert_to_dataframe):
        mock_stringify.return_value = self.results
        mock_convert_to_dataframe.side_effect = lambda x: MagicMock()
        mock_stat_frames.return_value = {
            'accuracy': {"mean": 0.875, "std": 0.025, "max": 0.9, "min": 0.85, "50th": 0.875, "70th": 0.8875, "80th": 0.9, "90th": 0.9, "95th": 0.9},
            'precision': {"mean": 0.775, "std": 0.025, "max": 0.8, "min": 0.75, "50th": 0.775, "70th": 0.7875, "80th": 0.8, "90th": 0.8, "95th": 0.8},
            'recall': {"mean": 0.675, "std": 0.025, "max": 0.7, "min": 0.65, "50th": 0.675, "70th": 0.6875, "80th": 0.7, "90th": 0.7, "95th": 0.7}
        }

        stats = analyze(self.results, self.result_dir, self.analyzed_keys)

        self.assertTrue(os.path.exists(self.result_dir))
        self.assertTrue(os.path.exists(os.path.join(self.result_dir, 'pred')))
        self.assertTrue(os.path.exists(os.path.join(self.result_dir, 'all.json')))
        self.assertTrue(os.path.exists(os.path.join(self.result_dir, 'stat.csv')))
        self.assertEqual(stats['accuracy']['mean'], 0.875)

if __name__ == '__main__':
    unittest.main()