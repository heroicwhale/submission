import unittest
import os
import json
import shutil
import pandas as pd
from unittest.mock import MagicMock, patch
from task.debug import analyze, run

class TestDebugFunctions(unittest.TestCase):

    def setUp(self):
        self.results = [
            {
                "meta_info": {"ticker_name": "AAPL"},
                "data": [1, 2, 3, 4, 5]
            },
            {
                "meta_info": {"ticker_name": "GOOGL"},
                "data": [2, 3, 4, 5, 6]
            }
        ]
        self.result_dir = "test_results"
        self.analyzed_keys = ["data"]

        if not os.path.exists(self.result_dir):
            os.makedirs(self.result_dir)

    def tearDown(self):
        if os.path.exists(self.result_dir):
            shutil.rmtree(self.result_dir)

    @patch('task.debug.stringify', return_value=json.dumps([{"meta_info": {"ticker_name": "AAPL"}, "data": [1, 2, 3, 4, 5]}]))
    @patch('task.debug.convert_to_dataframe', side_effect=lambda x: pd.DataFrame(x["data"], columns=["value"]))
    @patch('task.debug.stat_frames', return_value={"data": {"mean": 3, "std": 1.58, "max": 5, "min": 1, "50th": 3, "70th": 4, "80th": 4.5, "90th": 5, "95th": 5}})
    def test_analyze(self, mock_stat_frames, mock_convert_to_dataframe, mock_stringify):
        cur_stats = analyze(self.results, self.result_dir, self.analyzed_keys)

        self.assertTrue(os.path.exists(os.path.join(self.result_dir, 'pred')))
        self.assertTrue(os.path.exists(os.path.join(self.result_dir, 'all.json')))
        self.assertTrue(os.path.exists(os.path.join(self.result_dir, 'stat.csv')))

        with open(os.path.join(self.result_dir, 'all.json'), 'r') as f:
            data = json.load(f)
            self.assertEqual(data, json.dumps([{"meta_info": {"ticker_name": "AAPL"}, "data": [1, 2, 3, 4, 5]}]))

        self.assertEqual(cur_stats, {"data": {"mean": 3, "std": 1.58, "max": 5, "min": 1, "50th": 3, "70th": 4, "80th": 4.5, "90th": 5, "95th": 5}})


if __name__ == '__main__':
    unittest.main()