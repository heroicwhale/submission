import numpy as np
import pandas as pd

def stringify(x):
    """
    Recursively converts all elements in a given data structure to their string representations.

    Args:
        x (any): The input data structure which can be a dictionary, list, tuple, numpy array, or any other type.

    Returns:
        any: A new data structure with the same shape as the input, but with all elements converted to strings.
    """
    if isinstance(x, dict):
        return {str(k): stringify(v) for k, v in x.items()}
    if isinstance(x, list):
        return [stringify(v) for v in x]
    if isinstance(x, tuple):
        return tuple(stringify(v) for v in x)
    if isinstance(x, np.ndarray):
        return stringify(x.tolist())
    return str(x)

def convert_to_dataframe(data):
    """
    Converts the given data dictionary into a pandas DataFrame.
    Parameters:
    data (dict): A dictionary containing the following keys:
        - 'raw_data': A dictionary with:
            - 'source': A dictionary where keys are feature names and values are lists of feature values.
            - 'target': A dictionary where keys are target names and values are either scalars or lists of target values.
        - 'predicted': A dictionary with:
            - 'target': A dictionary where keys are target names and values are either scalars or lists of predicted target values.
    Returns:
    pd.DataFrame: A DataFrame where each row corresponds to a feature or target, and columns represent time points, predicted values, differences, and ratios.
    """
    time_list = list(range(len(data['raw_data']['source'][list(data['raw_data']['source'].keys())[0]])))

    raw_data_feature = data['raw_data']['source']
    raw_data_target = data['raw_data']['target']
    
    predicted_target = data['predicted']['target']
    
    df_data = {}
    
    for feature, values in raw_data_feature.items():
        for i, time in enumerate(time_list[:-1]):
            if feature not in df_data:
                df_data[feature] = {}
            df_data[feature][time] = float(values[i])
    

    for target, values in raw_data_target.items():
        for _, time in enumerate([time_list[-1]]):
            if target not in df_data:
                df_data[target] = {}
            # check if values is a scalar
            if isinstance(values, (int, float, np.int64, np.float64, np.float32, np.int32)):
                v = values
            else:
                v = values[-1]
            df_data[target][time] = float(v)
    
    for target, values in predicted_target.items():
        if target not in df_data:
            df_data[target] = {}
        if isinstance(values, (int, float, np.int64, np.float64, np.float32, np.int32)):
            v = values
        else:
            v = values[-1]
        df_data[target]["pred"] = float(v)
        df_data[target]["diff"] = float(v) - float(df_data[target][time_list[-1]])
        df_data[target]["ratio"] = (float(v) - float(df_data[target][time_list[-1]])) / float(df_data[target][time_list[-1]]) if float(df_data[target][time_list[-1]]) != 0 else float('nan')
    
    df = pd.DataFrame(df_data)
    
    df = df.transpose()
    
    return df