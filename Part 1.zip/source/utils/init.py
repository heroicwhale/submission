import random
import os
import time
import logging
import numpy as np
import tensorflow as tf
import keras

def fix_seed(seed):
    """
    Fixes the random seed for reproducibility across various libraries.

    This function sets the seed for the following libraries to ensure 
    deterministic behavior:
    - Python's built-in random module
    - NumPy
    - TensorFlow

    Additionally, it sets environment variables to further ensure 
    reproducibility in TensorFlow.

    Args:
        seed (int): The seed value to be used for random number generation.
    """
    random.seed(seed)
    np.random.seed(seed)
    tf.random.set_seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    os.environ['TF_DETERMINISTIC_OPS'] = '1'

def get_random_suffix(length):
    """
    Generate a random suffix of the specified length.

    Args:
        length (int): The length of the random suffix to generate.

    Returns:
        str: A random string of lowercase letters with the specified length.
    """
    return ''.join(random.choices('abcdefghijklmnopqrstuvwxyz', k=length))

def get_time_suffix():
    """
    Generates a string representing the current time in the format 'YYYYMMDDHHMMSS'.

    Returns:
        str: The current time formatted as 'YYYYMMDDHHMMSS'.
    """
    current_time = time.strftime('%Y%m%d%H%M%S')
    return current_time

class LossLogger(keras.callbacks.Callback):
    """
    A custom Keras callback to log the loss at the end of each epoch.

    Methods
    -------
    on_epoch_end(epoch, logs={})
        Called at the end of each epoch. Logs the epoch number and the loss values.

    Parameters
    ----------
    epoch : int
        The index of the epoch.
    logs : dict
        A dictionary containing the loss values for the epoch.
    """
    def on_epoch_end(self, epoch, logs={}):
        formated_logs = ' - '.join(['{}: {:.4f}'.format(k, v) for k, v in logs.items()])
        logging.getLogger('file_only_logger').info('Epoch {}: {}'.format(epoch, formated_logs))

def setup_logger(log_filename, log_level=logging.INFO):
    """
    Sets up a logger with both console and file handlers, using a custom formatter
    that aligns multi-line log messages.
    Args:
        log_filename (str): The filename for the log file.
        log_level (int, optional): The logging level. Defaults to logging.INFO.
    Returns:
        logging.Logger: The configured logger instance.
    """
    class AlignedMultiLineFormatter(logging.Formatter):
        def format(self, record):
            # First, format the log message using the base class format method
            message = super().format(record)
            # Split the message into multiple lines
            lines = message.splitlines()

            formatted_lines = [lines[0]]

            if len(lines) > 1:
                temp_record = logging.LogRecord(
                    name=record.name, 
                    level=record.levelno, 
                    pathname=record.pathname, 
                    lineno=record.lineno, 
                    msg='', 
                    args=(), 
                    exc_info=None
                )
                prefix = super().format(temp_record)
                prefix_length = len(prefix)
                # Align subsequent lines with the prefix
                for line in lines[1:]:
                    formatted_lines.append(' ' * prefix_length + line)

            # Join all lines into one string
            return '\n'.join(formatted_lines)
        
    logger = logging.getLogger()
    file_only_logger = logging.getLogger('file_only_logger')
    file_only_logger.propagate = False
    
    logger.setLevel(log_level)
    file_only_logger.setLevel(log_level)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(log_level)

    file_handler = logging.FileHandler(log_filename)
    file_handler.setLevel(log_level)

    formatter = AlignedMultiLineFormatter('%(asctime)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    file_only_logger.addHandler(file_handler)

    return logger