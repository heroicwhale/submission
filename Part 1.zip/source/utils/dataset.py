import numpy as np

def split_index(length, ratio_list, shuffle=False):
    """
    Splits indices into multiple groups based on given ratios.

    Parameters:
    length (int): The total number of indices to split.
    ratio_list (list of float): A list of ratios to split the indices. The sum of the ratios does not need to be 1.
    shuffle (bool, optional): If True, the indices will be shuffled before splitting. Default is False.

    Returns:
    list of numpy.ndarray: A list of arrays, each containing the indices for one of the groups.
    """
    if shuffle:
        index = np.random.permutation(length)
    else:
        index = np.arange(length)

    ratio_list = np.array(ratio_list)
    ratio_list = ratio_list / ratio_list.sum()
    ratio_list = (ratio_list * length).astype(int)

    index_list = []
    start = 0
    for ratio in ratio_list:
        index_list.append(index[start:start + ratio])
        start += ratio

    return index_list

def stat_frames(frames, target_keys):
    """
    Calculate statistical metrics for specified keys across multiple frames.

    Parameters:
    frames (dict): A dictionary where each key is a frame name and each value is another dictionary
                   containing a "ratio" dictionary with keys corresponding to target_keys.
    target_keys (list): A list of keys for which to calculate the statistics.

    Returns:
    dict: A dictionary where each key is one of the target_keys and each value is another dictionary
          containing the following statistical metrics for that key:
          - "mean": Mean of the ratios.
          - "std": Standard deviation of the ratios.
          - "max": Maximum value of the ratios.
          - "min": Minimum value of the ratios.
          - "50th": 50th percentile (median) of the ratios.
          - "70th": 70th percentile of the ratios.
          - "80th": 80th percentile of the ratios.
          - "90th": 90th percentile of the ratios.
          - "95th": 95th percentile of the ratios.
    """
    cur_stats = {}
    for key in target_keys:
        ratio_list = [abs(frames[name]["ratio"][key]) for name in frames]
        mean_val = np.mean(ratio_list)
        std_val = np.std(ratio_list)
        max_val = np.max(ratio_list)
        min_val = np.min(ratio_list)
        p50 = np.percentile(ratio_list, 50)
        p70 = np.percentile(ratio_list, 70)
        p80 = np.percentile(ratio_list, 80)
        p90 = np.percentile(ratio_list, 90)
        p95 = np.percentile(ratio_list, 95)
        cur_stats[key] = {
            "mean": mean_val,
            "std": std_val,
            "max": max_val,
            "min": min_val,
            "50th": p50,
            "70th": p70,
            "80th": p80,
            "90th": p90,
            "95th": p95,
        }
    return cur_stats