import os
import pickle

def load_cache(cache_file: str, default=None) -> any:
    """
    Load a cache from a file if it exists, otherwise return a default value.

    Args:
        cache_file (str): The path to the cache file.
        default (Any, optional): The default value to return if the cache file does not exist. Defaults to None.

    Returns:
        Any: The cached data if the file exists, otherwise the default value.
    """
    if os.path.exists(cache_file):
        with open(cache_file, "rb") as f:
            return pickle.load(f)
    return default

def save_cache(data: any, cache_file: str) -> None:
    """
    Save data to a cache file using pickle.

    Args:
        data (any): The data to be cached.
        cache_file (str): The path to the cache file where data will be saved.

    Raises:
        IOError: If the file cannot be opened or written to.
        pickle.PicklingError: If the data cannot be pickled.
    """
    with open(cache_file, "wb") as f:
        pickle.dump(data, f)