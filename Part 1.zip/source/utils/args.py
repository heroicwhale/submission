import yaml

class Config(object):
    """
    A class to convert a dictionary into an object with attribute-style access,
    and to support nested dictionaries as nested Config objects.

    Attributes:
        __dict__ (dict): Stores the attributes of the Config object.

    Methods:
        __init__(dictionary):
            Initializes the Config object with the given dictionary.
        
        __getattr__(item):
            Returns the value of the attribute if it exists, otherwise returns None.
        
        __setattr__(key, value):
            Sets the attribute with the given key to the given value.
        
        __delattr__(item):
            Deletes the attribute with the given key. Raises AttributeError if the attribute does not exist.
        
        __repr__():
            Returns a YAML string representation of the Config object.
        
        from_yaml(file_path: str):
            Class method to create a Config object from a YAML file.
    """
    def __init__(self, dictionary):
        for key, value in dictionary.items():
            if isinstance(value, dict):
                value = Config(value)
            self.__dict__[key] = value

    def __getattr__(self, item):
        if item in self.__dict__:
            return self.__dict__[item]
        else:
            return None

    def __setattr__(self, key, value):
        self.__dict__[key] = value

    def __delattr__(self, item):
        try:
            del self.__dict__[item]
        except KeyError:
            raise AttributeError(f"Config object has no attribute '{item}'")

    def __repr__(self):
        # Convert the object back to a dictionary for YAML conversion
        def to_dict(obj):
            if isinstance(obj, Config):
                return {key: to_dict(value) for key, value in obj.__dict__.items()}
            return obj

        return yaml.dump(to_dict(self), default_flow_style=False)

    @classmethod
    def from_yaml(cls, file_path: str):
        with open(file_path, 'r') as file:
            yaml_content = yaml.safe_load(file)
        return cls(yaml_content)